MONGO_URI = "mongodb+srv://denysnovokshchonov:IcrJZJfHQa551NZf@insulation.30xi9u0.mongodb.net/insulation?retryWrites=true&w=majority&appName=Insulation"
SECRET_KEY = "123"
