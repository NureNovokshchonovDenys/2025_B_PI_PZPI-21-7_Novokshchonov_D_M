def calculate_materials(params):
    try:
        floors = int(params.get('floors', 0))
        floor_height = float(params.get('floor_height', 0))
        slab_thickness = float(params.get('slab_thickness', 0))
        socle_area = float(params.get('socle_area', 0))
        tech_floor_area = float(params.get('tech_floor_area', 0))

        include_socle = params.get('include_socle') == 'on'
        include_tech_floor = params.get('include_tech_floor') == 'on'

        window_count = int(params.get('window_count', 0))
        window_area = float(params.get('window_area', 0))
        balcony_count = int(params.get('balcony_count', 0))
        balcony_area = float(params.get('balcony_area', 0))

        wall_length = float(params.get('wall_length', 0))
        wall_width = float(params.get('wall_width', 0))

        insulation_thickness = float(params.get('insulation_thickness', 0.05))  # default 5 cm
        include_glue = params.get('include_glue') == 'on'
        include_fixings = params.get('include_fixings') == 'on'
        finish_type = params.get('finish_type', '')

        full_floor_height = floor_height + slab_thickness
        perimeter = 2 * (wall_length + wall_width)
        wall_area_main = perimeter * full_floor_height * floors

        total_window_area = window_count * window_area
        total_balcony_area = balcony_count * balcony_area
        excluded_area = total_window_area + total_balcony_area

        additional_area = 0
        if include_socle:
            additional_area += socle_area
        if include_tech_floor:
            additional_area += tech_floor_area

        total_area = wall_area_main + additional_area - excluded_area
        total_area_with_margin = total_area * 1.1

        glue_kg = round(total_area * 3.5, 2) if include_glue else 0
        fixings_count = round(total_area * 6) if include_fixings else 0  

        finish_consumption = {
            'Штукатурка': 3.0,    
            'Фарбування': 0.25,    
            'Облицювання': 1.2     
        }

        finish_needed = round(total_area * finish_consumption.get(finish_type, 0), 2)

        return {
            'total_area': round(total_area, 2),
            'material_needed': round(total_area_with_margin, 2),
            'wall_area_main': round(wall_area_main, 2),
            'excluded_area': round(excluded_area, 2),
            'glue_needed': glue_kg,
            'fixings_needed': fixings_count,
            'finish_type': finish_type,
            'finish_needed': finish_needed,
            'insulation_thickness': insulation_thickness
        }

    except Exception as e:
        return {'error': str(e)}
