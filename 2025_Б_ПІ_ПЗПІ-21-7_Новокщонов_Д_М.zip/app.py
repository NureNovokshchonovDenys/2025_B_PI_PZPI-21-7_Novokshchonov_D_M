from flask import Flask, render_template, request, redirect, session, url_for, jsonify
from pymongo import MongoClient
import config
from calculator import calculate_materials
import report_generator
import json
import logging
from bson.objectid import ObjectId
from flask import request, redirect, url_for, flash
from werkzeug.security import generate_password_hash
from werkzeug.security import check_password_hash
from datetime import datetime

logging.basicConfig(level=logging.INFO)

app = Flask(__name__)
app.secret_key = config.SECRET_KEY
client = MongoClient(config.MONGO_URI)
db = client["Insulation1"]

logging.info(f"Connected to MongoDB database: {db.name}")

def load_translation(lang='ua'):
    with open(f"translations/{lang}.json", encoding='utf-8') as f:
        return json.load(f)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/debug/users')
def debug_users():
    users = list(db.users.find())
    for user in users:
        user["_id"] = str(user["_id"]) 
    return jsonify(users)

@app.route('/admin/add_user', methods=['POST'])
def add_user():
    username = request.form['username']
    password = request.form['password']
    role = request.form['role']
    hashed_password = generate_password_hash(password)
    
    db.users.insert_one({
        'username': username,
        'password': hashed_password,
        'role': role
    })
    flash('Користувача додано')
    return redirect(url_for('admin_panel'))

@app.route('/admin/delete_user/<user_id>', methods=['POST'])
def delete_user(user_id):
    db.users.delete_one({'_id': ObjectId(user_id)})
    flash('Користувача видалено')
    return redirect(url_for('admin_panel'))

@app.route('/admin/add_material', methods=['POST'])
def add_material():
    name = request.form['name']
    type_ = request.form['type']
    db.materials.insert_one({'name': name, 'type': type_})
    flash('Матеріал додано')
    return redirect(url_for('admin_panel'))

@app.route('/admin/delete_material/<material_id>', methods=['POST'])
def delete_material(material_id):
    db.materials.delete_one({'_id': ObjectId(material_id)})
    flash('Матеріал видалено')
    return redirect(url_for('admin_panel'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    msg = ''
    if request.method == 'POST':
        user = db.users.find_one({'username': request.form['username']})
        if user and check_password_hash(user['password'], request.form['password']):
            session['user'] = user['username']
            session['role'] = user['role']
            return redirect('/dashboard')
        else:
            msg = 'Невірний логін або пароль'
    return render_template('login.html', message=msg)

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect('/login')
    return render_template('dashboard.html', user=session['user'], role=session['role'])

@app.route('/calculate1', methods=['GET', 'POST'])
def calculator1():
    result = None
    materials = list(db.materials.find())

    if request.method == 'POST':
        form_data = request.form
        result = calculate_materials(form_data)
        result['type'] = form_data.get('material', '')

    return render_template('calculator.html', result=result, materials=materials)

@app.route('/calculate', methods=['GET', 'POST'])
def calculator():
    result = None
    materials = list(db.materials.find())
    print_link = None

    if request.method == 'POST':
        form_data = request.form.to_dict()
        result = calculate_materials(form_data)
        result['type'] = form_data.get('material', '')
        insulation_thickness = form_data.get('insulation_thickness', '')
        result['insulation_thickness'] = insulation_thickness
        user_id = session.get('user_id', 'guest')
        
        inserted = db.calculations.insert_one({
            'user': user_id,
            'params': form_data,
            'result': result,
            'created_at': datetime.now()
        })

        print_link = url_for('print_result', calc_id=str(inserted.inserted_id))

    return render_template('calculator.html', result=result, materials=materials, print_link=print_link)

@app.route('/projects')
def projects():
    if 'user' not in session:
        return redirect('/login')

    if session['user'] == 'admin':
        user_projects = db.calculations.find().sort('created_at', -1)
    else:
        user_projects = db.calculations.find({'user': session['user']}).sort('created_at', -1)

    return render_template('projects.html', projects=list(user_projects))

@app.route('/print/<calc_id>')
def print_result(calc_id):
    record = db.calculations.find_one({'_id': ObjectId(calc_id)})
    if not record:
        return "Розрахунок не знайдено", 404
    return render_template('print_result.html', record=record)

@app.route('/admin')
def admin_panel():
    if session.get('role') != 'admin':
        return redirect('/')
    users = list(db.users.find())
    materials = list(db.materials.find())
    return render_template('admin_panel.html', users=users, materials=materials)

if __name__ == '__main__':
    app.run(debug=True)
