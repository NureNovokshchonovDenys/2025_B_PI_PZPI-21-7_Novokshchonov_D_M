def generate_report(project):
    report = f"""
    Проєкт: {project['name']}
    Площа: {project['result']['area']} м²
    Тип утеплення: {project['result']['type']}
    Необхідно матеріалу: {project['result']['material_needed']} м²
    """
    return report
